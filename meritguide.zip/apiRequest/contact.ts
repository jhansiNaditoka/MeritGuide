import axios from "axios";
import { origin } from "./config";
import Cookies from 'js-cookie'


export const getContacts = async () => {

   
    try {
        const response = await axios({
            url:`${origin}/api/v1/contact/`,
            method:'get',
            headers:{
                // 'Authorization': `Bearer ${token}`, 
                'Content-Type':'application/json'
            }
        })

        const responseData = await response?.data

        return responseData;
    }
    catch (err:any) {
        console.log(err?.message);
        
    }
}


