const env:any = "prod"

export const origin = env == "dev" ? "http://localhost:3000": "https://m0t75t4921.execute-api.ap-south-1.amazonaws.com"

export const adminCookie = "faf61ac9d4fdb0000025bdf7375edksfjkdsfj"

