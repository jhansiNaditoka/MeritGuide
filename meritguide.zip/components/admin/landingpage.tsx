import React, { useEffect, useState } from "react";
import {Box, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography} from '@mui/material'
import Cookies from "js-cookie";

import { adminCookie } from "../../apiRequest/config";
import { adminUpdatePassword } from "../../apiRequest/admin";
import { getContacts } from "../../apiRequest/contact";
import AdminHeader from '../../components/admin/adminheader';


export default function Landingpage() {

    // const onclickLogOut = () => {
    //     Cookies.remove(adminCookie)
    //     window.location.href = '/'

    // }

    const [password,setpassword] = useState('')
    const [show,setShow] = useState(false)

    const onUpdatePassword = async() => {
        const response = await adminUpdatePassword({password:password})

        if (response?.message == 'success') {
            alert(response?.message)
            setpassword('')
        }
    }

    const [data,setData] = useState([] as any[])

    useEffect(() => {getData()},[])

    const getData = async () => {

        const response  = await getContacts() 

        if (Array.isArray(response)) {
            setData(response)
        }
    }

    return (
        <Box sx={{display:'flex',flexDirection:'column',height:'100vh',overflow:'auto',padding:2}} >

            
            {/*  */}
            <AdminHeader />
            {/*  */}

            <Box sx={{display:'flex',flexDirection:'column',padding:2,gap:2}} >

                <Box sx={{display:'flex',flexDirection:"column",gap:1}} >
                    <Typography sx={{color:"#000"}} >Update Password</Typography>
                    <Box sx={{display:'flex',gap:2,width:'300px'}} >
                        <TextField  size="small" value={password} onChange={(e:any) => setpassword(e?.target?.value)}  />
                        <Button onClick={() => onUpdatePassword()} >Submit</Button>
                    </Box>
                </Box>
            
            <Typography sx={{color:'#000'}} >Leads Data</Typography>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell align="left" sx={{color:'black'}} >
                                No
                            </TableCell>
                            <TableCell align="left" sx={{color:'black'}} >
                                Name
                            </TableCell>
                            <TableCell align="center" sx={{color:'black'}} >
                                email
                            </TableCell>
                            <TableCell align="center" sx={{color:'black'}} >
                                Phone Number
                            </TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>

                        {
                            data?.map((x:any,index:any) => 
                                <TableRow>
                            <TableCell align="left" sx={{color:'black'}}  >
                                {index + 1}
                            </TableCell>
                            <TableCell align="left" sx={{color:'black'}}  >
                                {x?.name}
                            </TableCell>
                            <TableCell align="center" sx={{color:'black'}}  >
                                {x?.email}
                            </TableCell>
                            <TableCell align="center" sx={{color:'black'}}  >
                                {x?.phone}
                            </TableCell>
                        </TableRow>
                            
                            )
                        }
                
                    </TableBody>
                </Table>
            </TableContainer>
            </Box>
        </Box>
    )
}