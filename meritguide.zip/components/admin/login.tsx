import { Box, Button, TextField, useScrollTrigger } from "@mui/material";
import React, { useState } from "react";
import { adminCookie } from "../../apiRequest/config";
import { adminLogin } from "../../apiRequest/admin";
import Cookies from "js-cookie";


export default function LoginPage () {

    const [email,setEmail] = useState('')
    const [password,setPassword] = useState('')

    const onClickSubmitLogin = async () => {

        const reqData = { email:email,password:password}

        const response = await adminLogin(reqData)

        if (response?.message == "success") {
            Cookies.set(adminCookie,response?.token)
            window.location.href= "/admin/dashboard"
            
        }
        else {
            alert('User Not Found')
        }

    }


    return (
        <Box sx={{height:'100vh', display:'flex',flexDirection:'column',alignItems:"center",justifyContent:"center",backgroundImage:'url(https://res.cloudinary.com/dybivlcnj/image/upload/v1715759664/images/WhatsApp_Image_2024-05-15_at_1.14.19_PM_w9chaq.jpg)',backgroundSize:'fill'}} >
             <Box sx={{display:'flex',flexDirection:"column",width:"320px",padding:2,borderRadius:'10px',backgroundColor:'rgba( 255, 255, 255,1 )',boxShadow: '0 8px 32px 0 rgba( 31, 38, 135, 0.37 )',backdropFilter:'blur( 0.5px )',WebkitBackdropFilter:'blur( 0.5px )',gap:2}} >
                <img src="https://res.cloudinary.com/dybivlcnj/image/upload/v1714373552/images/meritguide/7f756f7e-dd0b-4acf-b8c2-879898a95849_1_xfje88.png" alt="" style={{width:'120px',height:'60px',alignSelf:'center'}} />
                <TextField size="small" value={email} onChange={(e:any) => setEmail(e?.target?.value)} sx={{color:"black",background:"white"}}  variant="outlined" label="Email"  />
                <TextField size='small' type="password" value={password} onChange={(e:any) => setPassword(e?.target?.value)} sx={{color:"black",background:"white"}}  variant="outlined" label="Password"  />
                <Button sx={{width:'120px',alignSelf:'center'}}  onClick={() => onClickSubmitLogin()} variant='contained' >SUBMIT</Button>
             </Box>
        </Box>
    )
}