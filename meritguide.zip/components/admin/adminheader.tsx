import React, { useEffect } from 'react';
import {useState} from 'react';

import "../../css/adminheader.css";
import { adminCookie } from "../../apiRequest/config";
import { Box, Button, Typography } from '@mui/material';
import Cookies from 'js-cookie';


export default function AdminHeader(props:any) {

    const {tab} = props

    const [activeTab,setActiveTab] = useState(tab)
    const [show,setShow] = useState(false)


    

    const onclickLogOut = () => {
        Cookies.remove(adminCookie)
        window.location.href = '/admin'

    }


    const tabs = [
        {
            id:1,
            name:'Dashboard',
            location:'/admin/dashboard',
        },
        {
            id:2,
            name:'merit-Leads',
            location:'/admin/MeritLeads',
        },
        {
            id:3,
            name:'Blogs-page',
            location:'/admin/Blogs&news',
        },
        
    ]

    return (
                <nav className='container-fluid' >
                    <div className='container pt-3 pb-3 d-flex align-items-center justify-content-between' >
                        
                        <div className='d-flex align-items-center gap-2' >
                        <svg onClick={() => setShow(!show)} xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-list mr-2" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                        </svg>
                        <img loading="lazy" src="https://res.cloudinary.com/dybivlcnj/image/upload/c_crop,w_1050,h_300/v1714373552/images/meritguide/7f756f7e-dd0b-4acf-b8c2-879898a95849_1_xfje88.png" className='logo-admin-size' />
                        </div> 
                
                          <Box sx={{display:'flex',gap:1}} >
                    
                           <Button variant='contained' onClick={() => onclickLogOut()} >
                              Logout
                          </Button>
                          </Box>
                    </div>

                            <div onMouseLeave={() => setShow(false)} className={show ? 'side-nav side-nav-active' :'side-nav'} >
                            <div className='container d-flex justify-content-between' >
                            
                            <img loading="lazy" src="https://res.cloudinary.com/dybivlcnj/image/upload/c_crop,w_1050,h_300/v1714373552/images/meritguide/7f756f7e-dd0b-4acf-b8c2-879898a95849_1_xfje88.png" alt='logo' className='logo-admin' />
                            <svg onClick={()=>setShow(false)} xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-x-lg" viewBox="0 0 16 16">
                            <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                            </svg>
                            </div>
                            <div className='container sidebar-tile gap-2 mt-4' >
                                {
                                    tabs?.map((x:any) =>  
                                    <a className='anchor-cap'  href={x?.location} >
                                    <Box
                                    sx={{width:'100%',backgroundColor:activeTab == x?.id ? "gray":"#0066cc"
                                    ,color:activeTab == x?.id ? "black": "white",
                                    borderRadius:'10px',
                                    display:'flex',
                                    alignItems:'center',
                                    padding:'10px 20px'
                                } }
                                    >
                                       
                                        <Typography>{x?.name}</Typography>
                                        
                                        
                                    </Box>
                                    </a>
                                    )
                                }
                            </div>
                    </div>
                </nav>
    )

    
    

}




